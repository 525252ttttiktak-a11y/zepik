package com.paradox.app

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var btnJ: Button
    private lateinit var btnMode: Button
    private lateinit var btnCam: Button
    private lateinit var btnGal: Button
    private lateinit var orb: Orb
    private lateinit var status: TextView
    private var camUri: Uri? = null
    private var autoTried = false
    private var dark = true
    private val prefs by lazy { getSharedPreferences("p", MODE_PRIVATE) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val fg get() = if (dark) Color.WHITE else Color.BLACK

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Speaker.init(this)
        dark = prefs.getBoolean("dark", true)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(36), dp(12), dp(8))
            setBackgroundColor(if (dark) Color.parseColor("#0E1118") else Color.WHITE)
        }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply { text = "Zepik"; textSize = 26f; setTextColor(fg) }, LinearLayout.LayoutParams(0, -2, 1f))
        btnMode = Button(this)
        btnMode.setOnClickListener { add("Режим: ${Brain.modeName(Brain.nextMode(this))}", false) }
        btnJ = Button(this).apply { setOnClickListener { toggleVoice() } }
        head.addView(btnMode); head.addView(btnJ)
        head.addView(Button(this).apply {
            text = "⚙"
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        })
        orb = Orb(this)
        status = TextView(this).apply { textSize = 14f; gravity = Gravity.CENTER; setTextColor(fg) }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply { addView(list) }
        input = EditText(this).apply { hint = "Команда или вопрос"; setTextColor(fg); setHintTextColor(Color.GRAY) }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        bar.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        btnCam = Button(this).apply { text = "📷"; setOnClickListener { takePhoto() } }
        btnGal = Button(this).apply {
            text = "🖼"
            setOnClickListener { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 4) }
        }
        bar.addView(btnCam); bar.addView(btnGal)
        bar.addView(Button(this).apply {
            text = "➤"
            setOnClickListener {
                val t = input.text.toString().trim()
                if (t.isNotEmpty()) { input.setText(""); Brain.handle(this@MainActivity, t) }
            }
        })
        root.addView(head)
        root.addView(orb, LinearLayout.LayoutParams(dp(110), dp(110)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bar)
        setContentView(root)
        add("История команд появится здесь.", false)
    }

    override fun onResume() {
        super.onResume()
        if (prefs.getBoolean("dark", true) != dark) { recreate(); return }
        Brain.ui = { t, m -> add(t, m) }
        Brain.onMode = { runOnUiThread { applyModeUi() } }
        applyModeUi()
        if (!autoTried) {
            autoTried = true
            if (!VoiceService.running && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startVoice()
        }
    }

    override fun onPause() { Brain.ui = null; Brain.onMode = null; super.onPause() }

    private fun applyModeUi() {
        val m = prefs.getString("mode", "jarvis")!!
        btnMode.text = Brain.modeName(m)
        val v = if (m == "study") View.VISIBLE else View.GONE
        btnCam.visibility = v; btnGal.visibility = v
        val on = VoiceService.running
        btnJ.text = if (on) "🎙 Вкл" else "🎙 Выкл"
        status.text = if (on) "Слушаю. Скажи «Зепик, …»" else "Отдыхаю"
        orb.setActive(on && prefs.getBoolean("orb", true))
    }

    private fun toggleVoice() {
        if (VoiceService.running) {
            stopService(Intent(this, VoiceService::class.java)); btnJ.text = "🎙 Выкл"
            status.text = "Отдыхаю"; orb.setActive(false)
        } else if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startVoice()
        } else {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, "android.permission.POST_NOTIFICATIONS"), 2)
        }
    }

    private fun startVoice() {
        startForegroundService(Intent(this, VoiceService::class.java)); btnJ.text = "🎙 Вкл"
        status.text = "Слушаю. Скажи «Зепик, …»"; orb.setActive(prefs.getBoolean("orb", true))
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startVoice()
        else add("Без доступа к микрофону голос не работает", false)
    }

    private fun takePhoto() {
        val cv = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "zepik_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        }
        camUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
        startActivityForResult(Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, camUri), 3)
    }

    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        if (res != RESULT_OK) return
        val uri = if (rc == 3) camUri else if (rc == 4) data?.data else null
        if (uri != null) sendImage(uri)
    }

    private fun sendImage(uri: Uri) {
        val q = input.text.toString().trim().ifEmpty { "Что на фото? Если это задание, реши его и объясни." }
        input.setText("")
        Thread {
            try {
                val bmp = contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it) }
                val k = 1024f / maxOf(bmp.width, bmp.height)
                val sc = if (k < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt(), (bmp.height * k).toInt(), true) else bmp
                val out = ByteArrayOutputStream()
                sc.compress(Bitmap.CompressFormat.JPEG, 80, out)
                Brain.handle(this, q, Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP))
            } catch (e: Exception) {
                add("Не удалось открыть фото: ${e.message}", false)
            }
        }.start()
    }

    private fun add(text: String, mine: Boolean) = runOnUiThread {
        val v = TextView(this).apply {
            this.text = text; textSize = 16f; setTextColor(fg)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(Color.parseColor(if (dark) (if (mine) "#22406E" else "#1B2030") else (if (mine) "#CFE8FF" else "#EEEEEE")))
        }
        val lp = LinearLayout.LayoutParams(-2, -2)
        lp.setMargins(if (mine) dp(48) else 0, dp(4), if (mine) 0 else dp(48), dp(4))
        lp.gravity = if (mine) Gravity.END else Gravity.START
        list.addView(v, lp)
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }
}
