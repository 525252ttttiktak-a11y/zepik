package com.paradox.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class Orb(c: Context) : View(c) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1800; repeatCount = ValueAnimator.INFINITE
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    fun setActive(on: Boolean) {
        if (on) { if (!anim.isRunning) anim.start() } else { anim.cancel(); t = 0f; invalidate() }
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = minOf(cx, cy)
        for (i in 0..2) {
            val k = (t + i / 3f) % 1f
            paint.color = Color.argb(((1 - k) * 90).toInt(), 80, 140, 255)
            c.drawCircle(cx, cy, r * (0.45f + 0.55f * k), paint)
        }
        paint.color = Color.rgb(60, 110, 240)
        c.drawCircle(cx, cy, r * 0.38f, paint)
    }

    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
}
