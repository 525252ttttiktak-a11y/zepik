package com.paradox.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.view.KeyEvent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Быстрые команды по фразам: работают без интернета и без ИИ. Возвращают текст или null (не моя команда).
// Если текст начинается с "!", его нужно озвучить.
object Commands {
    fun run(ctx: Context, raw: String): String? {
        val t = raw.lowercase().replace(Regex("[^а-яёa-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val svc = ParadoxService.instance
        fun has(vararg w: String) = w.any { t.contains(it) }
        fun vol(dir: Int) { repeat(3) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI) } }
        fun key(k: Int) {
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, k)); am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, k))
        }
        fun glob(a: Int, ok: String) = if (svc == null) "!Включите службу Zepik в настройках" else { svc.performGlobalAction(a); ok }
        val off = has("выключи", "отключи", "выйди")
        return when {
            has("тише", "убавь звук", "уменьши звук", "потише") -> { vol(AudioManager.ADJUST_LOWER); "Тише" }
            has("громче", "прибавь звук", "увеличь звук", "погромче") -> { vol(AudioManager.ADJUST_RAISE); "Громче" }
            has("выключи звук", "без звука") -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI); "Звук выключен" }
            has("сверни все окна", "сверни окна", "на главный экран", "рабочий стол") || t == "домой" -> glob(AccessibilityService.GLOBAL_ACTION_HOME, "Главный экран")
            t == "назад" -> glob(AccessibilityService.GLOBAL_ACTION_BACK, "Назад")
            has("скриншот", "снимок экрана") -> glob(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT, "Скриншот")
            has("недавние", "переключи приложение") -> glob(AccessibilityService.GLOBAL_ACTION_RECENTS, "Недавние")
            has("заблокируй экран", "заблокируй телефон") -> glob(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN, "Экран заблокирован")
            has("шторку", "открой уведомления") -> glob(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, "Уведомления")
            has("концентрации", "не беспокоить") -> { Brain.dnd(ctx, !off); if (off) "Концентрация выключена" else "Концентрация включена" }
            has("фонарик") -> try {
                val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                cm.setTorchMode(cm.cameraIdList[0], !off); if (off) "Фонарик выключен" else "Фонарик включён"
            } catch (e: Exception) { "!Не получилось включить фонарик" }
            has("пауза", "останови музыку") -> { key(KeyEvent.KEYCODE_MEDIA_PAUSE); "Пауза" }
            has("включи музыку", "продолжи музыку") -> { key(KeyEvent.KEYCODE_MEDIA_PLAY); "Музыка" }
            has("следующий трек", "следующая песня", "следующий") || t == "дальше" -> { key(KeyEvent.KEYCODE_MEDIA_NEXT); "Следующий трек" }
            has("предыдущий трек", "прошлый трек", "предыдущий") -> { key(KeyEvent.KEYCODE_MEDIA_PREVIOUS); "Предыдущий трек" }
            has("сколько времени", "который час") -> "!Сейчас " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            t.startsWith("открой ") && !t.contains(" и ") -> {
                val n = t.removePrefix("открой ").trim()
                val pm = ctx.packageManager
                val app = pm.getInstalledApplications(0).firstOrNull { pm.getApplicationLabel(it).toString().contains(n, ignoreCase = true) }
                val li = app?.let { pm.getLaunchIntentForPackage(it.packageName) }
                if (li != null) { ctx.startActivity(li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "Открываю $n" } else null
            }
            else -> null
        }
    }
}
