package com.paradox.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

class VoiceService : Service() {
    companion object { @Volatile var running = false }
    private var sr: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var awaiting = false
    private var speaking = false
    private var awaitUntil = 0L

    override fun onBind(i: Intent?) = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("z", "Zepik", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "z").setContentTitle("Zepik слушает")
            .setContentText("Скажи кодовое слово").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        running = true
        Speaker.init(this)
        Speaker.onDone = { h.post { speaking = false; listen() } }
        listen()
        return START_STICKY
    }

    private fun again() { h.postDelayed({ listen() }, 600) }

    private fun listen() {
        if (!running || speaking) return
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) {
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) again() else heard(t)
                }
                override fun onError(e: Int) { again() }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, getSharedPreferences("p", MODE_PRIVATE).getBoolean("offline", false)))
        }
    }

    private fun heard(t: String) {
        val custom = getSharedPreferences("p", MODE_PRIVATE).getString("wake", "зепик")!!.ifBlank { "зепик" }
        val low = t.lowercase()
        val w = listOf(custom, "зепик", "зэпик", "зебик", "зепек", "zepik").firstOrNull { low.contains(it) }
        if (awaiting && System.currentTimeMillis() < awaitUntil) {
            awaiting = false; speaking = true; Brain.handle(this, t)
        } else if (w != null) {
            awaiting = false
            val rest = low.substringAfter(w).trim(' ', ',', '.', '!')
            speaking = true
            if (rest.startsWith("отдыхай") || rest.startsWith("отдохни") || rest.startsWith("выключись")) {
                Speaker.onDone = { h.post { stopSelf() } }
                Speaker.speak(this, "Отдыхаю, сэр. Откройте приложение, чтобы разбудить.")
            } else if (rest.length < 2) {
                awaiting = true; awaitUntil = System.currentTimeMillis() + 10000
                Speaker.speak(this, "Слушаю, сэр")
            } else Brain.handle(this, rest)
        } else again()
    }

    override fun onDestroy() {
        running = false
        Speaker.onDone = null
        Brain.onMode?.invoke()
        sr?.destroy()
        super.onDestroy()
    }
}
