package com.paradox.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*

object Overlay {
    private var root: View? = null

    fun show(s: AccessibilityService) {
        if (root != null) return
        val wm = s.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val p = s.getSharedPreferences("p", Context.MODE_PRIVATE)
        val d = s.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        fun shape(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
        fun btn(t: String, f: () -> Unit) = Button(s).apply { text = t; isAllCaps = false; setOnClickListener { f() } }

        val last = TextView(s).apply { text = "Zepik готов"; setTextColor(Color.WHITE); textSize = 14f; maxLines = 6 }
        Brain.feed = { t, mine -> if (!mine) last.post { last.text = t } }
        val modes = LinearLayout(s)
        listOf("🤖" to "jarvis", "🎮" to "game", "📚" to "study").forEach { (e, m) ->
            modes.addView(btn(e) { Brain.setMode(s, m); last.text = Brain.modeName(m) }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        val voice = Switch(s).apply {
            text = "Отвечать голосом"; setTextColor(Color.WHITE); isChecked = p.getBoolean("voice", true)
            setOnCheckedChangeListener { _, c -> p.edit().putBoolean("voice", c).apply() }
        }
        val speed = SeekBar(s).apply {
            max = 150; progress = p.getInt("rate", 100) - 50
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(b: SeekBar?, v: Int, u: Boolean) { p.edit().putInt("rate", v + 50).apply() }
                override fun onStartTrackingTouch(b: SeekBar?) {}
                override fun onStopTrackingTouch(b: SeekBar?) {}
            })
        }
        val row = LinearLayout(s)
        row.addView(btn("🎙") {
            if (VoiceService.running) s.stopService(Intent(s, VoiceService::class.java))
            else try { s.startForegroundService(Intent(s, VoiceService::class.java)) }
            catch (e: Exception) { Toast.makeText(s, "Открой Zepik, чтобы включить микрофон", Toast.LENGTH_SHORT).show() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(btn("⏹") { ParadoxService.stop = true }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(btn("💬") {
            s.startActivity(Intent(s, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }, LinearLayout.LayoutParams(0, -2, 1f))
        val panel = LinearLayout(s).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE; alpha = 0f
            setPadding(dp(12), dp(12), dp(12), dp(12)); background = shape(0xF0202124.toInt(), 16)
        }
        listOf(last, modes, voice, speed, row).forEach { panel.addView(it) }
        val bubble = TextView(s).apply {
            text = "Z"; textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = shape(0xFF6750A4.toInt(), 28)
        }
        val box = LinearLayout(s).apply { orientation = LinearLayout.VERTICAL; minimumWidth = dp(260) }
        box.addView(bubble, LinearLayout.LayoutParams(dp(56), dp(56)))
        box.addView(panel, LinearLayout.LayoutParams(dp(260), -2))
        val lp = WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START; lp.x = dp(8); lp.y = dp(240)
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - sx) + Math.abs(e.rawY - sy) > dp(8)) moved = true
                    if (moved) { lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(box, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    if (panel.visibility == View.GONE) {
                        panel.visibility = View.VISIBLE; panel.animate().alpha(1f).setDuration(220).start()
                    } else panel.animate().alpha(0f).setDuration(220).withEndAction { panel.visibility = View.GONE }.start()
                }
            }
            true
        }
        wm.addView(box, lp)
        root = box
    }

    fun hide(s: AccessibilityService) {
        Brain.feed = null
        root?.let { try { (s.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it) } catch (e: Exception) {} }
        root = null
    }
}
