package com.paradox.app

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false
    var onDone: (() -> Unit)? = null

    fun init(c: Context) {
        if (tts != null) return
        tts = TextToSpeech(c.applicationContext) { ok ->
            ready = ok == TextToSpeech.SUCCESS
            if (ready) {
                tts?.language = Locale("ru", "RU")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { onDone?.invoke() }
                    override fun onError(id: String?) { onDone?.invoke() }
                })
            }
        }
    }

    fun voices() = tts?.voices?.filter { it.locale.language == "ru" }?.sortedBy { it.name } ?: emptyList()

    fun speak(c: Context, t: String) {
        val p = c.getSharedPreferences("p", Context.MODE_PRIVATE)
        if (!p.getBoolean("voice", true) || !ready) { onDone?.invoke(); return }
        tts?.setSpeechRate(p.getInt("rate", 100) / 100f)
        tts?.setPitch(p.getInt("pitch", 85) / 100f)
        p.getString("voiceName", "")?.takeIf { it.isNotEmpty() }?.let { n ->
            tts?.voices?.firstOrNull { it.name == n }?.let { tts?.voice = it }
        }
        tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "z")
    }
}
