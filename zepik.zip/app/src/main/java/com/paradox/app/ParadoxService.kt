package com.paradox.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class ParadoxService : AccessibilityService() {
    companion object {
        var instance: ParadoxService? = null
        @Volatile var stop = false
        @Volatile var running = false
        val DANGER = listOf("оплат", "купить", "pay", "buy", "удалить", "delete", "перевод")
        const val SYS = "Ты управляешь Android-телефоном. Отвечай ТОЛЬКО одним JSON-объектом: " +
            "{\"action\":\"click|type|scroll|back|home|open|done\",\"id\":число,\"text\":\"...\",\"say\":\"кратко что делаешь\"}. " +
            "click и type используют id из списка экрана; type вводит text в поле; open принимает название приложения в text; " +
            "done когда задача выполнена. Один шаг за раз. Платежи и удаление не выполняй."
    }

    override fun onServiceConnected() { instance = this; Overlay.show(this) }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; Overlay.hide(this); return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun run(goal: String, key: String, status: (String) -> Unit) {
        if (running) return
        running = true; stop = false
        Thread {
            try {
                performGlobalAction(GLOBAL_ACTION_HOME)
                Thread.sleep(1500)
                val log = StringBuilder()
                for (step in 1..20) {
                    if (stop) { status("Остановлено"); break }
                    val nodes = ArrayList<AccessibilityNodeInfo>()
                    val sb = StringBuilder()
                    collect(rootInActiveWindow, nodes, sb)
                    val prompt = "Задача: $goal\nУже сделано:\n$log\nЭкран (id|текст|свойства):\n$sb"
                    val reply = ask(key, prompt)
                    val j = JSONObject(reply.substring(reply.indexOf('{'), reply.lastIndexOf('}') + 1))
                    val act = j.optString("action")
                    val txt = j.optString("text")
                    status("Шаг $step: ${j.optString("say")}")
                    when (act) {
                        "click" -> {
                            val n = nodes.getOrNull(j.optInt("id", -1))
                            if (n != null) {
                                val label = (n.text ?: n.contentDescription ?: "").toString().lowercase()
                                if (DANGER.any { label.contains(it) }) {
                                    status("Остановился: опасное действие «$label». Сделай это сам."); break
                                }
                                tap(n)
                            }
                        }
                        "type" -> {
                            val n = nodes.getOrNull(j.optInt("id", -1))
                            val a = Bundle()
                            a.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, txt)
                            n?.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, a)
                        }
                        "scroll" -> findScrollable(rootInActiveWindow)?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
                        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
                        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
                        "open" -> openApp(txt)
                        "done" -> { status("Готово: ${j.optString("say")}"); break }
                    }
                    log.append("$step. $act ${j.optString("id")} $txt\n")
                    Thread.sleep(1500)
                }
            } catch (e: Exception) {
                status("Ошибка: ${e.message}")
            } finally {
                running = false
            }
        }.start()
    }

    private fun collect(n: AccessibilityNodeInfo?, out: ArrayList<AccessibilityNodeInfo>, sb: StringBuilder) {
        if (n == null || out.size > 100) return
        val t = (n.text ?: n.contentDescription)?.toString()
        if (!t.isNullOrBlank() || n.isEditable) {
            sb.append(out.size).append('|').append(t ?: "").append('|')
            if (n.isClickable) sb.append("tap ")
            if (n.isEditable) sb.append("edit")
            sb.append('\n')
            out.add(n)
        }
        for (i in 0 until n.childCount) collect(n.getChild(i), out, sb)
    }

    private fun findScrollable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) findScrollable(n.getChild(i))?.let { return it }
        return null
    }

    private fun tap(n: AccessibilityNodeInfo) {
        var x: AccessibilityNodeInfo? = n
        while (x != null && !x.isClickable) x = x.parent
        (x ?: n).performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun openApp(name: String) {
        val pm = packageManager
        val app = pm.getInstalledApplications(0).firstOrNull {
            pm.getApplicationLabel(it).toString().contains(name, ignoreCase = true)
        } ?: return
        pm.getLaunchIntentForPackage(app.packageName)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(it)
        }
    }

    private fun ask(key: String, prompt: String): String {
        val model = getSharedPreferences("p", MODE_PRIVATE).getString("model", "gemini-flash-latest")!!
        val contents = JSONArray().put(JSONObject().put("role", "user")
            .put("parts", JSONArray().put(JSONObject().put("text", prompt))))
        return Gemini.call(key, model, SYS, contents, true)
    }
}
