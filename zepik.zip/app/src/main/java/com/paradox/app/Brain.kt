package com.paradox.app

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject

object Brain {
    private val history = JSONArray()
    var ui: ((String, Boolean) -> Unit)? = null
    var feed: ((String, Boolean) -> Unit)? = null
    var onMode: (() -> Unit)? = null
    private val MODES = listOf("jarvis", "game", "study")
    const val ROUTER = "Ты голосовой ассистент Zepik на телефоне Android. Отвечай ТОЛЬКО одним JSON: " +
        "{\"mode\":\"chat\" или \"phone\" или \"switch\",\"say\":\"текст\"}. mode=phone, если пользователь просит что-то сделать " +
        "на телефоне (открыть приложение, нажать, написать сообщение, изменить настройку); тогда say это короткое подтверждение. " +
        "mode=switch, если просят переключить режим: добавь поле \"set\" со значением jarvis, game или study. " +
        "Иначе mode=chat, и say это ответ на языке пользователя. "

    fun modeName(m: String) = when (m) { "game" -> "🎮 Игровой"; "study" -> "📚 Учебный"; else -> "🤖 Джарвис" }

    fun emit(t: String, mine: Boolean) { ui?.invoke(t, mine); feed?.invoke(t, mine) }

    fun setMode(ctx: Context, m: String) {
        val p = ctx.getSharedPreferences("p", Context.MODE_PRIVATE)
        val old = p.getString("mode", "jarvis")
        p.edit().putString("mode", m).apply()
        if (m == "game" || old == "game") dnd(ctx, m == "game")
        onMode?.invoke()
    }

    fun nextMode(ctx: Context): String {
        val cur = ctx.getSharedPreferences("p", Context.MODE_PRIVATE).getString("mode", "jarvis")
        val n = MODES[(MODES.indexOf(cur) + 1) % MODES.size]
        setMode(ctx, n)
        return n
    }

    fun dnd(ctx: Context, on: Boolean) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.isNotificationPolicyAccessGranted) {
            nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL)
        } else if (on) {
            emit("Дайте Zepik доступ к «Не беспокоить», тогда игровой режим сможет его включать.", false)
            try { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {}
        }
    }

    private fun modePrompt(m: String) = when (m) {
        "game" -> "Режим «Игровой»: ты бодрый игровой напарник. Предлагай и веди игры (викторина, загадки, «20 вопросов», слова), " +
            "давай советы по играм. Отвечай коротко и энергично. "
        "study" -> "Режим «Учебный»: ты терпеливый репетитор. Объясняй пошагово и простыми словами, приводи примеры. " +
            "Если есть фото с заданием, прочитай его, реши и объясни ход решения. mode всегда chat. "
        else -> "Говори как Джарвис из «Железного человека»: вежливо, спокойно, с лёгкой иронией, обращайся «сэр». " +
            "Ответы короткие (1-3 предложения), если не просят подробно. "
    }

    fun reply(ctx: Context, t: String) { emit(t, false); Speaker.speak(ctx, t) }

    private fun turn(role: String, text: String, img: String? = null) {
        val parts = JSONArray().put(JSONObject().put("text", text))
        if (img != null) parts.put(JSONObject().put("inline_data",
            JSONObject().put("mime_type", "image/jpeg").put("data", img)))
        history.put(JSONObject().put("role", role).put("parts", parts))
    }

    private fun stripImages() {
        for (i in 0 until history.length()) {
            val parts = history.getJSONObject(i).getJSONArray("parts")
            for (k in parts.length() - 1 downTo 0) if (parts.getJSONObject(k).has("inline_data")) parts.remove(k)
        }
    }

    fun handle(ctx: Context, text: String, img: String? = null) {
        val p = ctx.getSharedPreferences("p", Context.MODE_PRIVATE)
        val key = p.getString("k", "")!!
        emit(if (img != null) "📷 $text" else text, true)
        if (img == null) {
            val c = Commands.run(ctx, text)
            if (c != null) {
                if (c.startsWith("!")) reply(ctx, c.drop(1)) else { emit("✓ $c", false); Speaker.onDone?.invoke() }
                return
            }
        }
        if (key.isEmpty()) { reply(ctx, "Сначала вставь API-ключ в настройках"); return }
        synchronized(history) {
            turn("user", text, img)
            while (history.length() > 20) { history.remove(0); history.remove(0) }
        }
        Thread {
            try {
                val sys = ROUTER + modePrompt(p.getString("mode", "jarvis")!!) + p.getString("persona", "")
                val r = Gemini.call(key, p.getString("model", "gemini-flash-latest")!!, sys, history, true)
                val j = JSONObject(r.substring(r.indexOf('{'), r.lastIndexOf('}') + 1))
                val s = j.optString("say")
                synchronized(history) { stripImages(); turn("model", s) }
                reply(ctx, s)
                if (j.optString("mode") == "switch") setMode(ctx, j.optString("set", "jarvis"))
                if (j.optString("mode") == "phone") {
                    val svc = ParadoxService.instance
                    if (svc == null) {
                        reply(ctx, "Включите службу Zepik в настройках")
                    } else svc.run(text, key) { m ->
                        emit(m, false)
                        if (m.startsWith("Готово") || m.startsWith("Остановил") || m.startsWith("Ошибка")) Speaker.speak(ctx, m)
                    }
                }
            } catch (e: Exception) {
                synchronized(history) { stripImages() }
                reply(ctx, "Ошибка: ${e.message}")
            }
        }.start()
    }
}
